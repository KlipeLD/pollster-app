<?php

return [

    'nav_survey_index' => 'Surveys',
    'no_data_available' => 'No data available'

];
