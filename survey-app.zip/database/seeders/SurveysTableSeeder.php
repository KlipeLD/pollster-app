<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Survey;

class SurveysTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // Survey::truncate();

        // $faker = \Faker\Factory::create();

        // for ($i = 0; $i < 50; $i++) {
        //     Survey::create([
        //         'title' => $faker->sentence,
        //         'body' => $faker->paragraph,
        //     ]);
        // }
    }
}
